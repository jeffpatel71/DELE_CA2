# Deep-Q-Network-Inverted-Pendulum
Reinforcement leaning control of an inverted pendulum using Double (+Duelling) Deep Q-Leaning (DDQN) with Prioritised Replay Buffer (PER) on the OpenAi Gym environment.
